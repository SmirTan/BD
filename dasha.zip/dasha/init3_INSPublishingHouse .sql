insert into PublishingHouse values (3001,'АСТ',null);
insert into PublishingHouse values (3002,'АСТ','Лунные хроники');
insert into PublishingHouse values (3003,'МИФ',null);
insert into PublishingHouse values (3004,'Робинс','Зильбер');
insert into PublishingHouse values (3005,'Bubble Comics','Майор Гром');
insert into PublishingHouse values (3006,'ЭСКМО','Яркие страницы');
insert into PublishingHouse values (3007,'ЭСКМО',null);
insert into PublishingHouse values (3008,'Азбука',null);
insert into PublishingHouse values (3009,'Азбука','Манга');
insert into PublishingHouse values (3010,'Синдбад',null);
insert into PublishingHouse values (3011,'Popcorn books','Rebel');

